<nav>
    <div class="nav-left">
        <a href="../backend/main.php">Főoldal</a>
        <a href="../backend/download.php">Letöltés</a>
        <a href="../backend/contact.php">Kapcsolat</a>
        
        <!-- Csak bejelentkezett felhasználóknak jelenik meg -->
        <?php if (!empty($_SESSION['user_id'])): ?>
            <a href="../backend/updates.php">Frissítések</a>
        <?php endif; ?>
    </div>
    <div class="nav-right">
        <?php if (!empty($_SESSION['username'])): ?>
            <!-- Beállítás ikon -->
            <div class="settings-dropdown">
                <a href="#" id="settings-icon">
                    <i class="fas fa-cog" style="font-size: 1.5em;"></i>
                </a>
                <div class="dropdown-menu" id="dropdown-menu">
                    <a href="../backend/player.php">Profil</a>
                    <a href="../backend/settings.php">Beállítások</a>
                    <a href="../backend/logout.php">Kijelentkezés</a>
                </div>
            </div>
        <?php else: ?>
            <a href="../backend/login.php">Bejelentkezés</a>
            <a href="../backend/register.php">Regisztráció</a>
        <?php endif; ?>
    </div>
</nav>
