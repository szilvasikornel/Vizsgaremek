<footer>
        <small>© 2025 Last Knight. Minden jog fenntartva.</small>
</footer>
